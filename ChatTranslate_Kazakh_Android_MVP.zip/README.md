# ChatTranslate — English ↔ Kazakh Android keyboard MVP

This is a starter Android Studio project for a WhatsApp-friendly translation keyboard.

## What it does
- Installs as an Android keyboard (IME).
- Lets you type English or Kazakh.
- Calls the OpenAI Responses API for translation.
- Inserts the translated text into the active WhatsApp text field.
- Designed for natural conversational English ↔ Kazakh translation.

## Setup
1. Open this folder in Android Studio.
2. Build/install the app on your Android phone.
3. Enable ChatTranslate under Android Keyboard/Input Method settings.
4. Select it in WhatsApp.
5. Configure an OpenAI API key in the code's `cfg` preference before use.

IMPORTANT: This is an MVP. Do not ship a real API key hard-coded into a public APK. A production version should use a secure backend so the key is never embedded in the keyboard APK.

## Production upgrades
- One-tap "Natural / Formal / Flirty / Reply" modes.
- Incoming-message translation via Android notification access (with explicit permission).
- Conversation context.
- On-device language detection.
- Streaming translation.
- Secure backend/token exchange.
- Privacy controls and opt-out.
