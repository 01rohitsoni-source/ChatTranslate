package com.example.chattranslate

import android.inputmethodservice.InputMethodService
import android.view.*
import android.widget.*
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class TranslateIME : InputMethodService() {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    private val client=OkHttpClient.Builder().connectTimeout(20,TimeUnit.SECONDS).readTimeout(30,TimeUnit.SECONDS).build()

    override fun onCreateInputView(): View {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(8,8,8,8) }
        val input=EditText(this).apply { hint="Type English or Kazakh…"; minLines=2 }
        val row=LinearLayout(this)
        val translate=Button(this).apply { text="Translate ↔" }
        val send=Button(this).apply { text="Insert" }
        row.addView(translate, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(send, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(input); root.addView(row)
        translate.setOnClickListener {
            val text=input.text.toString()
            if(text.isBlank()) return@setOnClickListener
            translate(text) { result -> input.setText(result); input.setSelection(result.length) }
        }
        send.setOnClickListener {
            val result=input.text.toString()
            currentInputConnection.commitText(result,1)
            input.setText("")
        }
        return root
    }

    private fun translate(text:String, done:(String)->Unit) {
        val key=getSharedPreferences("cfg",0).getString("api_key","") ?: ""
        if(key.isBlank()){ done("Set OPENAI_API_KEY in app settings/source before use."); return }
        scope.launch {
            try {
                val body=JSONObject().apply {
                    put("model","gpt-5.6-luna")
                    put("input","Translate between English and Kazakh. Preserve meaning, names, tone and emojis. Return only the translation. Text: $text")
                }.toString()
                val req=Request.Builder().url("https://api.openai.com/v1/responses")
                    .addHeader("Authorization","Bearer $key")
                    .post(body.toRequestBody("application/json".toMediaType())).build()
                val res=client.newCall(req).execute()
                val raw=res.body?.string()?:""
                val out=JSONObject(raw).optString("output_text")
                withContext(Dispatchers.Main){ done(if(out.isBlank()) "Translation failed: HTTP ${res.code}" else out) }
            } catch(e:Exception){ withContext(Dispatchers.Main){ done("Error: ${e.message}") } }
        }
    }
}
