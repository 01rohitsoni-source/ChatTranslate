package com.example.chattranslate

import android.app.Activity
import android.os.Bundle
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(40,40,40,40) }
        val title=TextView(this).apply { text="ChatTranslate • English ↔ Kazakh"; textSize=24f }
        val info=TextView(this).apply { text="Enable the ChatTranslate keyboard in Android Settings, then select it inside WhatsApp.\n\nThe MVP translates typed text and replaces it in the chat box."; textSize=16f; setPadding(0,30,0,30) }
        val open=Button(this).apply { text="Open keyboard settings"; setOnClickListener {
            startActivity(android.content.Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS))
        }}
        box.addView(title); box.addView(info); box.addView(open); setContentView(box)
    }
}
